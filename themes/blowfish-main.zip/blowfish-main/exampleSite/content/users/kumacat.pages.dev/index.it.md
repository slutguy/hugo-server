---
                title: "kumacat.pages.dev"
                tags: [Sito personale, Blog]
                externalUrl: "https://kumacat.pages.dev"
                weight: 881
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

