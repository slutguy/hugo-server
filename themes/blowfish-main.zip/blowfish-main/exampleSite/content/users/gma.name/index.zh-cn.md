---
                title: "gma.name"
                tags: [个人网站]
                externalUrl: "https://gma.name"
                weight: 481
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

