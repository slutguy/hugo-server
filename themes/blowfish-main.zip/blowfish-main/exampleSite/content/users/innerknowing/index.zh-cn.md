---
                title: "innerknowing"
                tags: [个人网站, 建模师]
                externalUrl: "https://innerknowing.xyz/en/"
                weight: 711
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

