---
                title: "innerknowing"
                tags: [Personal site,Modeller]
                externalUrl: "https://innerknowing.xyz/en/"
                weight: 711
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
