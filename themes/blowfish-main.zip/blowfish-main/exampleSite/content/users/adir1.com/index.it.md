---
                title: "adir1.com"
                tags: [Sito personale]
                externalUrl: "https://adir1.com/"
                weight: 211
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

