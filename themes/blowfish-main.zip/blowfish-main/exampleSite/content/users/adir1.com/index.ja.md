---
                title: "adir1.com"
                tags: [個人サイト]
                externalUrl: "https://adir1.com/"
                weight: 211
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

