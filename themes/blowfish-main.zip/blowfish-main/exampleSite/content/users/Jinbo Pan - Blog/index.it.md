---
                title: "Jinbo Pan - Blog"
                tags: [Sito personale, Blog, Blog sulla tecnologia]
                externalUrl: "https://www.panjinbo.com/"
                weight: 851
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

