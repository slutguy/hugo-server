---
                title: "Jinbo Pan - Blog"
                tags: [個人サイト, ブログ, テクノロジーブログ]
                externalUrl: "https://www.panjinbo.com/"
                weight: 851
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

