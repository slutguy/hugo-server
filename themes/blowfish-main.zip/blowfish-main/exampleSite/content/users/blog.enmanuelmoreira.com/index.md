---
                title: "blog.enmanuelmoreira.com"
                tags: [Personal site]
                externalUrl: "https://blog.enmanuelmoreira.com"
                weight: 371
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
