---
                title: "Adam Madej - Gameplay Animator"
                tags: [Portfolio Site,Blog,Personal Site]
                externalUrl: "http://www.adammadej.com/"
                weight: 741
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
