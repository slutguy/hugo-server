---
                title: "Adam Madej - Gameplay Animator"
                tags: [ポートフォリオサイト, ブログ, 個人サイト]
                externalUrl: "http://www.adammadej.com/"
                weight: 741
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

