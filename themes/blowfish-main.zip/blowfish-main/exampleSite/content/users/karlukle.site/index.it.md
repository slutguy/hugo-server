---
                title: "karlukle.site"
                tags: [Blog personale]
                externalUrl: "https://karlukle.site"
                weight: 731
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

