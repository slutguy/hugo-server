---
                title: "BoringTech.net"
                tags: [Personal Site,Blog]
                externalUrl: "https://boringtech.net/"
                weight: 611
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
