---
                title: "BoringTech.net"
                tags: [個人サイト, ブログ]
                externalUrl: "https://boringtech.net/"
                weight: 611
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

