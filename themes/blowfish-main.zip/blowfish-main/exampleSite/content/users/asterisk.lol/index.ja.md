---
                title: "asterisk.lol"
                tags: [ブログ, 個人サイト]
                externalUrl: "https://asterisk.lol"
                weight: 661
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

