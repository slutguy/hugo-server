---
                title: "asterisk.lol"
                tags: [Blog, Sito personale]
                externalUrl: "https://asterisk.lol"
                weight: 661
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

