---
                title: "asterisk.lol"
                tags: [Blog,Personal Site]
                externalUrl: "https://asterisk.lol"
                weight: 661
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
