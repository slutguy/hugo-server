---
                title: "Middle of Nowhere"
                tags: [個人サイト, ブログ]
                externalUrl: "https://blog.wtcx.dev/"
                weight: 821
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

