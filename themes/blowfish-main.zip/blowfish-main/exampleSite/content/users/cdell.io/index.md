---
                title: "cdell.io"
                tags: [Personal site]
                externalUrl: "https://cdell.io"
                weight: 151
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
