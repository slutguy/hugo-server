---
title: "多作者"
date: 2022-10-12
draft: false
description: "多作者设置示例"
tags: ["作者", "示例"]
summary: "如何使用多个作者的简单示例。"
showAuthor: false
authors:
  - "nunocoracao"
  - "secondauthor"
type: 'sample'
---

这是具有多个作者的文章的示例。